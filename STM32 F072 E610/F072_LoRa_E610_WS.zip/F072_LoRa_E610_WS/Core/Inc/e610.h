/*
 * e610.h
 *
 *	HAL -> E610 Library
 *
 *  Created on: Nov 15, 2025
 *      Author: luuk-
 */

#ifndef INC_E610_H_
#define INC_E610_H_

#include "stdint.h"
#include "string.h"
#include "stm32f0xx_hal.h"

//Enums
enum Head {
    SAVE_ON_EXIT = 0xC0,
    NO_SAVE_ON_EXIT = 0xC2
};

// address high en low invoeren

enum UartParity {
    NO_PARITY,
    ODD_PARITY,
    EVEN_PARITY
};

enum UartBaudRate {
    BAUD_2400,
    BAUD_4800,
    BAUD_9600,
    BAUD_19200,
    BAUD_38400,
    BAUD_57600,
    BAUD_115200,
	BAUD_230400
};

enum AirRate {
    AIR_RATE_0k5,
    AIR_RATE_1k5,
    AIR_RATE_3k5,
    AIR_RATE_5k5,
    AIR_RATE_6k5,
    AIR_RATE_11k,
    AIR_RATE_13k,
	AIR_RATE_21k,
	AIR_RATE_26k,
	AIR_RATE_42k,
	AIR_RATE_51k,
	AIR_RATE_82k,
	AIR_RATE_76k,
	AIR_RATE_125k,
	AIR_RATE_160k,
	AIR_RATE_410k,
	AIR_RATE_470k
};

// channel is 0-100 waarbij 0 410MHz, en 100 510MHz

enum TransparencyMode {
    TRANSPARENT,
    FIXED
};

enum TransmissionPower {
	POWER_20DBM,
	POWER_17DBM,
	POWER_14DBM,
	POWER_10DBM
};

enum RssiEnable {
	RSSI_CLOSE,
	RSSI_OPEN
};

enum RssiReceive {
	RSSI_RECV_CLOSE,
	RSSI_RECV_OPEN
};

enum Policy {
	POLICY_DISTANCE,
	POLICY_SPEED
};

enum RelayMode {
	RELAY_CLOSE,
	RELAY_OPEN
};


//Structs
typedef struct EbyteSettings {
	enum Head head;
    uint8_t addr_h;
    uint8_t addr_l;
    uint8_t net_id;
    enum UartBaudRate baud;
    enum AirRate air_rate;
    enum UartParity parity;
    enum RssiEnable rssi_en;
    enum Policy policy;
    enum TransmissionPower power;
    uint8_t channel;
    enum RssiReceive rssi_recv;
    enum TransparencyMode mode;
    enum RelayMode relay_mode;
    uint8_t crypt_h;
    uint8_t crypt_l;

}ebytesettings;


//Funcs
void set_baudrate(uint32_t baud, USART_TypeDef * huart);
void set_baudrate_with_disable(uint32_t baud, USART_TypeDef * huart);

void set_continuous_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin);
void set_transmission_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin);
void set_settings_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin);
void set_sleep_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin);

void wait_for_aux_high(GPIO_TypeDef * aux_gpio, uint16_t aux_pin);
void wait_for_aux_low(GPIO_TypeDef * aux_gpio, uint16_t aux_pin);

void settings_to_buf(ebytesettings settings, uint8_t *buf);
ebytesettings  buf_to_settings(uint8_t *buf);
void send_settings(UART_HandleTypeDef * usart, ebytesettings settings);
ebytesettings  retrieve_settings(UART_HandleTypeDef * huart);

uint8_t cmp_settings(ebytesettings *settings1, ebytesettings *settings2);


#endif /* INC_E610_H_ */

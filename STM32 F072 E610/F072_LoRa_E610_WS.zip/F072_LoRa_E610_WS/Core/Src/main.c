/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "e610.h"
#include "math.h"
#include "ARGB.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

enum TypeVerlichting {
	KERST,
	LEDSTRIP,
};

typedef struct {
	uint8_t red;
	uint8_t green;
	uint8_t blue;
} RGB_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */


#define MAX_LED 8
#define USE_BRIGHTNESS 1
#define timer_period 255

#define DIP_PIN_1 1
#define DIP_PIN_2 2
#define DIP_PIN_3 4
#define DIP_PIN_4 8
#define DIP_PIN_5 16
#define DIP_PIN_6 32
#define DIP_PIN_7 64
#define DIP_PIN_8 128

#define DATA_TRANSMISSION_SIZE 54
#define CHANNELS_USED 7

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim15;
DMA_HandleTypeDef hdma_tim2_ch4;

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_rx;

/* USER CODE BEGIN PV */

//UART
uint8_t Tx_data[54];
uint8_t Rx_data[513];
uint8_t DMX_data[513];
uint8_t our_data[CHANNELS_USED]; //[r1][g1][b1][r2][g2][b2]

uint8_t MODE = 6;

//Addressable LED
uint8_t LED_Data[MAX_LED][4];
uint8_t LED_Mod[MAX_LED][4];  // for brightness

//ID
uint8_t DIP_ID;

//Channel config
uint8_t devices_per_sender = 80;
uint8_t channels_per_device = CHANNELS_USED; //6

//Panic button flag
uint8_t panic = 0;
uint8_t panic_button = 0;

//WS led programs
uint8_t program = 0;
uint8_t old_program = 0;
RGB_t color[NUM_PIXELS];


#define RAINBOW_LEN (sizeof(rainbow) / sizeof(rainbow[0]))

//General
uint16_t tick = 0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM15_Init(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint8_t get_channel_by_id(uint8_t id, uint8_t multiplier, uint8_t division) {

	return (id / division) * multiplier;
}

uint8_t get_offset_by_id(uint8_t id, uint8_t division) {

	return id % division;
}

void increment_timers(uint8_t increment_amount)
{
	TIM2->CCR1 = TIM2->CCR1 + increment_amount;
	TIM2->CCR2 = TIM2->CCR2 + increment_amount;
	TIM2->CCR3 = TIM2->CCR3 + increment_amount;
	TIM3->CCR1 = TIM3->CCR1 + increment_amount;
	TIM3->CCR2 = TIM3->CCR2 + increment_amount;
	TIM3->CCR3 = TIM3->CCR3 + increment_amount;
}

void set_timers(uint8_t set_amount)
{
	TIM2->CCR1 = set_amount;
	TIM2->CCR2 = set_amount;
	TIM2->CCR3 = set_amount;
	TIM3->CCR1 = set_amount;
	TIM3->CCR2 = set_amount;
	TIM3->CCR3 = set_amount;
}

void panic_mode()
{
	TIM2->CCR1 = 255;
	TIM2->CCR2 = 255;
	TIM2->CCR3 = 255;
	TIM3->CCR1 = 255;
	TIM3->CCR2 = 255;
	TIM3->CCR3 = 255;
}

void update_timers()
{
	TIM2->CCR1 = our_data[5];
	TIM2->CCR2 = our_data[4];
	TIM2->CCR3 = our_data[3];
	TIM3->CCR1 = our_data[2];
	TIM3->CCR2 = our_data[1];
	TIM3->CCR3 = our_data[0];
}

uint8_t scale_val(uint8_t input, uint8_t input_max, uint8_t output_max){
	uint16_t temp = (input * output_max) / input_max;
	return temp;
}

void update_timers_scaled(uint8_t tim2_max, uint8_t tim3_max)
{
	TIM2->CCR1 = scale_val(our_data[5], 255, tim2_max);
	TIM2->CCR2 = scale_val(our_data[4], 255, tim2_max);
	TIM2->CCR3 = scale_val(our_data[3], 255, tim2_max);
	TIM3->CCR1 = scale_val(our_data[2], 255, tim3_max);
	TIM3->CCR2 = scale_val(our_data[1], 255, tim3_max);
	TIM3->CCR3 = scale_val(our_data[0], 255, tim3_max);
}

void update_timers_half()
{
	TIM2->CCR1 = our_data[2];
	TIM2->CCR2 = our_data[1];
	TIM2->CCR3 = our_data[0];
	TIM3->CCR1 = our_data[2];
	TIM3->CCR2 = our_data[1];
	TIM3->CCR3 = our_data[0];
}

void set_kerst_timer(TIM_TypeDef*  timer){
	//Save our leds! Hiermee kan 12V op een ledje via PWM
	timer->PSC = 1;
	timer->ARR = 5100; //4400 max, <4000 overlijden rood en blauw. groen en wit kunnen 3000 aan. meer dan 10000 nodig als je rood en geel fatsoenlijk wil gebruiken
}

void set_led_timer(TIM_TypeDef*  timer){
	//Save our leds! Hiermee kan 12V op een ledje via PWM
	timer->PSC = 0;
	timer->ARR = 255; //4400 max, <4000 overlijden rood en blauw. groen en wit kunnen 3000 aan. meer dan 10000 nodig als je rood en geel fatsoenlijk wil gebruiken
}

uint8_t get_id(){

	uint8_t id = 0;

	if (HAL_GPIO_ReadPin(DIP1_GPIO_Port, DIP1_Pin)){
		id |= DIP_PIN_1;
	}

	if (HAL_GPIO_ReadPin(DIP2_GPIO_Port, DIP2_Pin)){
		id |= DIP_PIN_2;
	}

	if (HAL_GPIO_ReadPin(DIP3_GPIO_Port, DIP3_Pin)){
		id |= DIP_PIN_3;
	}

	if (HAL_GPIO_ReadPin(DIP4_GPIO_Port, DIP4_Pin)){
		id |= DIP_PIN_4;
	}

	if (HAL_GPIO_ReadPin(DIP5_GPIO_Port, DIP5_Pin)){
		id |= DIP_PIN_5;
	}

	if (HAL_GPIO_ReadPin(DIP6_GPIO_Port, DIP6_Pin)){
		id |= DIP_PIN_6;
	}

	return id;
}

uint8_t init_e610(){

	set_settings_mode(M0_GPIO_Port, M0_Pin, M1_GPIO_Port, M1_Pin);

	set_baudrate_with_disable(9600, USART1);

	HAL_Delay(40);

	ebytesettings cur_settings = retrieve_settings(&huart1);

	ebytesettings settings = {
			.head = SAVE_ON_EXIT,
			.addr_h = 0,
			.addr_l = 0,
			.net_id = 0,
			.baud = BAUD_230400,
			.air_rate = AIR_RATE_470k,
			.parity = NO_PARITY,
			.rssi_en = RSSI_CLOSE,
			.policy = POLICY_SPEED,
			.power = POWER_20DBM,
			.channel = 0,
			.rssi_recv = RSSI_RECV_CLOSE,
			.mode = TRANSPARENT,
			.relay_mode = RELAY_CLOSE,
			.crypt_l = 0,
			.crypt_h = 0
	};

	if(!cmp_settings(&settings, &cur_settings)){

		HAL_Delay(10);

		send_settings(&huart1, settings);

		HAL_Delay(10);

		cur_settings = retrieve_settings(&huart1);

		if(!cmp_settings(&settings, &cur_settings)){
			return 0;
		}
	}

	set_baudrate_with_disable(230400, USART1);

	set_transmission_mode(M0_GPIO_Port, M0_Pin, M1_GPIO_Port, M1_Pin);

	wait_for_aux_high(AUX_GPIO_Port, AUX_Pin);

	return 1;
}


void program_clear_strip(){
	ARGB_Clear(); // Clear strip
	while (ARGB_Show() != ARGB_OK){};
}

void program_white_pulsing(){

	uint8_t mod = tick % 255;

	for (uint16_t i = 0; i < NUM_PIXELS; i++) {
        color[i].red = mod;
        color[i].green = mod;
        color[i].blue = mod;
	}
	while (ARGB_Show() != ARGB_OK){};
}

void program_green_purple_switching(uint8_t group_amount, uint16_t switch_rate){

	uint8_t target_green[3] = {20, 255, 30};
	uint8_t target_purple[3] = {130, 20, 255};
	uint8_t phase = (tick / switch_rate) & 1;
	uint8_t mod_group = 0;

	for (uint16_t i = 0; i < NUM_PIXELS; i++) {
	    if (i % group_amount == 0) {
	        mod_group++;
	    }

	    uint8_t *target = ((mod_group & 1) ^ phase) ? target_green : target_purple;

	    // RED
	    if (color[i].red < target[0]) color[i].red++;
	    else if (color[i].red > target[0]) color[i].red--;

	    // GREEN
	    if (color[i].green < target[1]) color[i].green++;
	    else if (color[i].green > target[1]) color[i].green--;

	    // BLUE
	    if (color[i].blue < target[2]) color[i].blue++;
	    else if (color[i].blue > target[2]) color[i].blue--;
	}
}

void program_rainbow_fade(uint16_t switch_rate)
{

	/* Prevent division by zero */
	if (switch_rate == 0) return;

	uint16_t ticks_per_change = (switch_rate / 255);
	if (ticks_per_change == 0) {
		ticks_per_change = 1;
	}

	uint16_t tick_cycle = tick % switch_rate;

	/* Hue moves from 0 → 255 over switch_rate ticks */
	uint8_t mod = tick_cycle / ticks_per_change;

	for (uint16_t i = 0; i < NUM_PIXELS; i++) {
		HSV2RGB(mod, 255, 255, &color[i].red, &color[i].green, &color[i].blue);
	}

}


void program_rainbow_movement(uint16_t switch_rate, uint16_t separation)
{


	/* Prevent division by zero */
	if (switch_rate == 0) return;

	uint16_t ticks_per_change = (switch_rate / 255);
	if (ticks_per_change == 0) {
		ticks_per_change = 1;
	}

	uint16_t tick_cycle = tick % switch_rate;

	/* Hue moves from 0 → 255 over switch_rate ticks */
	uint8_t mod = tick_cycle / ticks_per_change;

	for (uint16_t i = 0; i < NUM_PIXELS; i++) {
		HSV2RGB(mod + i*3, 255, 255, &color[i].red, &color[i].green, &color[i].blue);
	}
}


void smart_led_controller(){

	//program = our_data[6];
	program = 12;

	if(program != old_program){
		tick = 0;
		old_program = program;
	}

	switch(program){
	case 0:
		program_clear_strip(); //off
		break;
	case 1: //White pulsing
		program_white_pulsing();
		break;
	case 2: //Paria green purple switching
		program_green_purple_switching(11, 1000);
		break;
	case 3: //Paria green purple up
		break;
	case 4: //Paria green purple down
		break;
	case 5: //Paria green only switching
		break;
	case 6: //Paria green only up
		break;
	case 7: //Paria green only down
		break;
	case 8: //Paria purple switching
		break;
	case 9: //Paria purple up
		break;
	case 10: //Paria purple down
		break;
	case 11:
		program_rainbow_fade(5000);
		break;
	case 12:
		program_rainbow_movement(5000, 1000);
		break;
	default:
		program_clear_strip(); // off
		break;
	}

	for (uint16_t i = 0; i < NUM_PIXELS; i++) {
		ARGB_SetRGB(i, color[i].red, color[i].green, color[i].blue);
	}
	while (ARGB_Show() != ARGB_OK){};

}

//https://controllerstech.com/interface-ws2812-with-stm32/


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USB_DEVICE_Init();
  MX_TIM15_Init();
  /* USER CODE BEGIN 2 */

	DIP_ID = get_id();


	/*
	if (!init_e610()){
		while(1){
			HAL_GPIO_WritePin(PNC_LED_GPIO_Port, PNC_LED_Pin, SET);
			HAL_Delay(1000);
			HAL_GPIO_WritePin(PNC_LED_GPIO_Port, PNC_LED_Pin, RESET);
			HAL_Delay(1000);
		}
	}
	*/

	// enable LINE IDLE detect
	HAL_UARTEx_ReceiveToIdle_DMA(&huart1, (uint8_t *) Rx_data, sizeof(Rx_data));
	__HAL_DMA_DISABLE_IT(&hdma_usart1_rx, DMA_IT_HT);

	//Dumb RGB strip mode
	if (MODE == 2){
		;;
	} else {
		//Start timers
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
	}

	uint8_t timer_val = 0;

	if (HAL_GPIO_ReadPin(DIP7_GPIO_Port, DIP7_Pin)){
		set_kerst_timer(TIM2);
	} else {
		set_led_timer(TIM2);
	}

	if (HAL_GPIO_ReadPin(DIP8_GPIO_Port, DIP8_Pin)){
		set_kerst_timer(TIM3);
	} else {
		set_led_timer(TIM3);
	}


	  ARGB_Init();  // Initialization

	  ARGB_Clear(); // Clear strip
	  while (ARGB_Show() != ARGB_OK){}; // Update - Option 1

	  uint8_t green_color = 0;
	  uint8_t red_color = 0;
	  uint8_t blue_color = 0;
	  uint8_t dir = 1;

	  uint8_t select_color = 0;
	  uint8_t led_selected = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while(1){
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

		//HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_10);

		/*
		while (panic == 1){
			panicMode();
			HAL_GPIO_WritePin(PNC_LED_GPIO_Port, PNC_LED_Pin, SET);
		}

		if(HAL_GPIO_ReadPin(PNC_LED_GPIO_Port, PNC_LED_Pin)) {
			HAL_GPIO_WritePin(PNC_LED_GPIO_Port, PNC_LED_Pin, RESET);
		}
		*/

		//Test by using RealTerm. Open the COM port of the E32 device (and optionally select Hex in Display As) and go to the Send tab. Using the Send Numbers button it's possible to send integers instead of ASCII characters.
		//Copy data and put it in our array
		memcpy(&our_data, &DMX_data[get_offset_by_id(DIP_ID, devices_per_sender)*channels_per_device], sizeof(our_data));

		switch (MODE) {
		case 1:
			update_timers();
			break;
		case 2://Reserved for smart led strip testing
			//ARGB_Clear();

			ARGB_Clear();
			ARGB_SetRGB(led_selected, green_color, red_color, blue_color);

			while (ARGB_Show() != ARGB_OK){};

	        // --- Fading logic ---
	        uint8_t *current;

	        // Pick which color we are modifying
	        if      (select_color == 0) current = &green_color;
	        else if (select_color == 1) current = &red_color;
	        else                        current = &blue_color;

	        // Change brightness
	        if (dir) (*current)++;
	        else     (*current)--;

	        // Check state transitions
	        if (*current == 255) {
	            dir = 0; // fade down
	        }
	        else if (*current == 0) {
	            dir = 1; // fade up

	            // Switch to next color when hitting 0
	            select_color++;
	            if (select_color > 2) {
	                select_color = 0;
	                led_selected++;
	            }
	        }

	        if(led_selected >= NUM_PIXELS){
	        	led_selected = 0;
	        }

			break;
		case 3://Led blinky mode
			HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
			HAL_Delay(100);
			break;

		case 4://up test


			if (timer_val < 255) {
				timer_val++;
			} else {
				timer_val = 0;
			}

			set_timers(timer_val);

			HAL_Delay(20);

		case 5:
			update_timers_half();
			break;

		case 6:
			update_timers_scaled(59, 255); //Dumb strip part
			smart_led_controller();//WS led part
			break;
		default:
			break;
		}

	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB|RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the Systick
  */
  HAL_SYSTICK_Config(6000);
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK_DIV8);
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */
  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */
  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 59;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */
  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */
  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */
  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 255;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */
  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM15 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM15_Init(void)
{

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 0;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 60-1;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM15_Init 2 */

  /* USER CODE END TIM15_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */
  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */
  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_RXOVERRUNDISABLE_INIT|UART_ADVFEATURE_DMADISABLEONERROR_INIT;
  huart1.AdvancedInit.OverrunDisable = UART_ADVFEATURE_OVERRUN_DISABLE;
  huart1.AdvancedInit.DMADisableonRxError = UART_ADVFEATURE_DMA_DISABLEONRXERROR;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
  /* USER CODE END USART1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);
  /* DMA1_Channel4_5_6_7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_5_6_7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_Pin|PNC_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, M1_Pin|M0_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : AUX_Pin */
  GPIO_InitStruct.Pin = AUX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(AUX_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 PA5 PA9 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : DIP4_Pin DIP3_Pin DIP2_Pin DIP1_Pin
                           DIP5_Pin DIP6_Pin DIP7_Pin DIP8_Pin */
  GPIO_InitStruct.Pin = DIP4_Pin|DIP3_Pin|DIP2_Pin|DIP1_Pin
                          |DIP5_Pin|DIP6_Pin|DIP7_Pin|DIP8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LED_Pin PNC_LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin|PNC_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PANIC_Pin */
  GPIO_InitStruct.Pin = PANIC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(PANIC_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : M1_Pin */
  GPIO_InitStruct.Pin = M1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(M1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : M0_Pin */
  GPIO_InitStruct.Pin = M0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(M0_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB5 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/*
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
	HAL_UART_Receive_IT(&huart1, Rx_data, 40);
}
 */

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if (huart->Instance == USART1)
	{
		// https://controllerstech.com/uart-dma-with-idle-line-detection/

		//Toggle LED to indicate received message
		HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);

		//Copy data into DMX buffer
		memcpy(&DMX_data[0], &Rx_data[0], sizeof(Rx_data));

		//Empty buffer to prevent wrong data remaining in buffer
		memset(&Rx_data, 0, sizeof(Rx_data));

		/* start the DMA again */
		HAL_UARTEx_ReceiveToIdle_DMA(&huart1, (uint8_t *) Rx_data, sizeof(Rx_data));
		__HAL_DMA_DISABLE_IT(&hdma_usart1_rx, DMA_IT_HT);

	}
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	switch(GPIO_Pin){
		case AUX_Pin:
			//misschien kan hier een uart abort gezet worden. Hierdoor wordt de uart afgekapt wanneer de e32 zegt dat het ontvangen klaar is?

			break;

		case PANIC_Pin:
			//panic = !panic;
			//panic_button = 1; //No more panic button :)

			break;
		default:
			break;
	}
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

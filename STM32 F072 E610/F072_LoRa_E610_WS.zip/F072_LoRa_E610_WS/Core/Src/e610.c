/*
 * e49.c
 *
 *	HAL -> E49 Library
 *
 *  Created on: Jul 10, 2025
 *      Author: luuk-
 */

#include <e610.h>

// === CONSTANTS ===
#define EBYTE_E610_SETTING_SIZE	9
#define EBYTE_COMMAND_SIZE      3
#define EBYTE_UART_TIMEOUT      1000

#define EBYTE_GET_SAVED_PARAMETERS {0xC1, 0x00, 0x08}
#define EBYTE_GET_VERSION_INFO    {0xC3, 0xC3, 0xC3}

void set_baudrate(uint32_t baud, USART_TypeDef * usart)
{
    uint32_t pClock = HAL_RCC_GetSysClockFreq(); // Hard-code or call a function to obtain it
    uint32_t usartDiv = (pClock / baud);

    uint32_t reg = usart->BRR;
    reg &= ~0xffff; // Clear the lower 16 bits

    reg |= usartDiv;

    usart->BRR = reg;
}

void set_baudrate_with_disable(uint32_t baud, USART_TypeDef * usart){

	usart -> CR1 &= ~(USART_CR1_UE); //Uart disable flag
	set_baudrate(baud, usart);
	usart -> CR1 |= USART_CR1_UE;
}

void set_continuous_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin){
	//Set pins to transmission mode

	HAL_GPIO_WritePin(m0_gpio, m0_pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(m1_gpio, m1_pin, GPIO_PIN_RESET);
}

void set_transmission_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin){
	//Set pins to transmission mode

	HAL_GPIO_WritePin(m0_gpio, m0_pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(m1_gpio, m1_pin, GPIO_PIN_RESET);
}

void set_settings_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin){
	//Set pins to settings mode

	HAL_GPIO_WritePin(m0_gpio, m0_pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(m1_gpio, m1_pin, GPIO_PIN_SET);
}

void set_sleep_mode(GPIO_TypeDef * m0_gpio, uint16_t m0_pin, GPIO_TypeDef * m1_gpio, uint16_t m1_pin){
	//Set pins to sleep mode

	HAL_GPIO_WritePin(m0_gpio, m0_pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(m1_gpio, m1_pin, GPIO_PIN_SET);
}

void wait_for_aux_high(GPIO_TypeDef * aux_gpio, uint16_t aux_pin){
	//Wait for aux pin to go high again, indicating ready

	while(!HAL_GPIO_ReadPin(aux_gpio, aux_pin)){
		__NOP(); //do nothing
	}
}

void wait_for_aux_low(GPIO_TypeDef * aux_gpio, uint16_t aux_pin){
	//Wait for aux pin to go low

	while(HAL_GPIO_ReadPin(aux_gpio, aux_pin)){
		__NOP(); //do nothing
	}
}

// === ENCODING ===
void settings_to_buf(ebytesettings settings, uint8_t *buf)
{
    if (!buf) return;

    buf[0] = settings.head;    // 0xC0 (save) or 0xC2 (temp

    buf[1] = 0;    // starting address
    buf[2] = EBYTE_E610_SETTING_SIZE;    // length

    buf[3] = settings.addr_h;   // ADDH
    buf[4] = settings.addr_l;   // ADDL
    buf[5] = settings.net_id;   // ADDL

    // --- REG0 (0x03): baud/air rate ---
    buf[6] = (settings.baud     << 5) |   // bits 7-5
             (settings.air_rate);    // bits 4-0

    // --- REG1 (0x04): parity/RSSI/policy/power ---
    buf[7] = (settings.parity << 6) |  // bits 7-6
             (settings.rssi_en << 5) |  // bit 5
             (settings.policy << 2) |   // bits 4-2
			 (settings.power);   // bits 1-0

    // --- REG2 (0x05): channel ---
    buf[8] = settings.channel;

    // --- REG3 (0x06): RSSI recv/mode/relay ---
    buf[9] = (settings.rssi_recv << 7) |   // bit 7
             (settings.mode << 6) |	// bit 6
             (settings.relay_mode << 4); // bit 4

    // --- Keys ---
    buf[10] = settings.crypt_h;
    buf[11] = settings.crypt_l;

}

ebytesettings buf_to_settings(uint8_t *buf)
{
    ebytesettings s = {0};
    if (!buf) return s;

    s.head  = buf[0];
    // buf[1] start register
    // buf[2] length

    s.addr_h = buf[3];
    s.addr_l = buf[4];
    s.net_id = buf[5];

    // --- REG0 at buf[6] ---
    s.baud      = (buf[6] >> 5) & 0x07;   // bits 7–5
    s.air_rate  =  buf[6]       & 0x1F;   // bits 4–0

    // --- REG1 at buf[7] ---
    s.parity  = (buf[7] >> 6) & 0x03;     // bits 7–6
    s.rssi_en = (buf[7] >> 5) & 0x01;     // bit 5
    s.policy  = (buf[7] >> 2) & 0x07;     // bits 4–2
    s.power   =  buf[7]       & 0x03;     // bits 1–0

    // --- REG2 ---
    s.channel = buf[8];

    // --- REG3 at buf[9] ---
    s.rssi_recv  = (buf[9] >> 7) & 0x01;  // bit 7
    s.mode       = (buf[9] >> 6) & 0x01;  // bit 6
    s.relay_mode = (buf[9] >> 4) & 0x01;  // bit 4

    // Keys
    s.crypt_h = buf[10];
    s.crypt_l = buf[11];

    return s;
}


// === SEND / RETRIEVE ===
void send_settings(UART_HandleTypeDef *huart, ebytesettings settings) {
    uint8_t tx_buf[EBYTE_E610_SETTING_SIZE + EBYTE_COMMAND_SIZE];
    uint8_t rx_buf[EBYTE_E610_SETTING_SIZE + EBYTE_COMMAND_SIZE];

    settings_to_buf(settings, tx_buf);

    HAL_UART_Transmit(huart, tx_buf, EBYTE_E610_SETTING_SIZE + EBYTE_COMMAND_SIZE, EBYTE_UART_TIMEOUT);
    HAL_UART_Receive(huart, rx_buf, EBYTE_E610_SETTING_SIZE + EBYTE_COMMAND_SIZE, EBYTE_UART_TIMEOUT);
}

ebytesettings retrieve_settings(UART_HandleTypeDef *huart) {
    uint8_t tx_buf[EBYTE_COMMAND_SIZE] = EBYTE_GET_SAVED_PARAMETERS;
    uint8_t rx_buf[EBYTE_E610_SETTING_SIZE + EBYTE_COMMAND_SIZE];

    HAL_UART_Transmit(huart, tx_buf, EBYTE_COMMAND_SIZE, EBYTE_UART_TIMEOUT);
    HAL_UART_Receive(huart, rx_buf, EBYTE_E610_SETTING_SIZE + EBYTE_COMMAND_SIZE, EBYTE_UART_TIMEOUT);

    return buf_to_settings(rx_buf);
}

// === COMPARISON ===
uint8_t cmp_settings(ebytesettings *a, ebytesettings *b)
{
    if (!a || !b) return 0;

    //if (a->head       != b->head)       return 0; Head doesnt have to be the same, 0xC1 is result anyway...
    if (a->addr_h     != b->addr_h)     return 0;
    if (a->addr_l     != b->addr_l)     return 0;
    if (a->net_id     != b->net_id)     return 0;

    // REG0
    if (a->baud       != b->baud)       return 0;
    if (a->air_rate   != b->air_rate)   return 0;

    // REG1
    if (a->parity     != b->parity)     return 0;
    if (a->rssi_en    != b->rssi_en)    return 0;
    if (a->policy     != b->policy)     return 0;
    if (a->power      != b->power)      return 0;

    // REG2
    if (a->channel    != b->channel)    return 0;

    // REG3
    if (a->rssi_recv  != b->rssi_recv)  return 0;
    if (a->mode       != b->mode)       return 0;
    if (a->relay_mode != b->relay_mode) return 0;


    return 1; // all fields match
}


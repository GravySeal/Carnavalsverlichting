===========
NXP PXP GPU
===========

API
---

:ref:`lv_draw_pxp`

:ref:`lv_draw_pxp_blend`

:ref:`lv_gpu_nxp_pxp`

:ref:`lv_gpu_nxp_pxp_osa`

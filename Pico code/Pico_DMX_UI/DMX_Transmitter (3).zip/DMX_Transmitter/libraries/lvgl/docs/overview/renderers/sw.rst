=================
Software renderer
=================

API
---

:ref:`lv_draw_sw`

:ref:`lv_draw_sw_blend`

:ref:`lv_draw_sw_dither`

:ref:`lv_draw_sw_gradient`

typedef int dummy_int_t;

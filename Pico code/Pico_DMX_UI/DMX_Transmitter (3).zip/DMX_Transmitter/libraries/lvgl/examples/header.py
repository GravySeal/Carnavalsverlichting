#!/opt/bin/lv_micropython -i

import lvgl as lv
import display_driver

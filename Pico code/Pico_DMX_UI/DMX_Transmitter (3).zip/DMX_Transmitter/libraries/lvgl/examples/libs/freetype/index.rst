Open a front with FreeType
--------------------------

.. lv_example:: libs/freetype/lv_example_freetype_1
  :language: c


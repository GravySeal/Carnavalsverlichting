/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define AUX_Pin GPIO_PIN_13
#define AUX_GPIO_Port GPIOC
#define DIP4_Pin GPIO_PIN_1
#define DIP4_GPIO_Port GPIOB
#define DIP3_Pin GPIO_PIN_2
#define DIP3_GPIO_Port GPIOB
#define DIP2_Pin GPIO_PIN_10
#define DIP2_GPIO_Port GPIOB
#define DIP1_Pin GPIO_PIN_11
#define DIP1_GPIO_Port GPIOB
#define DIP5_Pin GPIO_PIN_12
#define DIP5_GPIO_Port GPIOB
#define DIP6_Pin GPIO_PIN_13
#define DIP6_GPIO_Port GPIOB
#define DIP7_Pin GPIO_PIN_14
#define DIP7_GPIO_Port GPIOB
#define DIP8_Pin GPIO_PIN_15
#define DIP8_GPIO_Port GPIOB
#define LED_Pin GPIO_PIN_8
#define LED_GPIO_Port GPIOA
#define PANIC_Pin GPIO_PIN_15
#define PANIC_GPIO_Port GPIOA
#define PANIC_EXTI_IRQn EXTI4_15_IRQn
#define M1_Pin GPIO_PIN_3
#define M1_GPIO_Port GPIOB
#define M0_Pin GPIO_PIN_4
#define M0_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
enum HEAD {
	save_on_exit = 0xC0,
	no_save_on_exit = 0xC2
};

enum UART_PARITY {
	no_parity = 0,
	odd_parity,
	even_parity
};

enum UART_BAUD_RATE {
	baud_1200 = 0,
	baud_2400,
	baud_4800,
	baud_9600,
	baud_19200,
	baud_38400,
	baud_57600,
	baud_115200
};

enum AIR_RATE {
	air_rate_2400 = 0,
	air_rate_2400_1,
	air_rate_2400_2,
	air_rate_4800,
	air_rate_9600,
	air_rate_19200,
	air_rate_19200_1,
	air_rate_19200_2
};

enum COM_CHANNEL {
	channel_0 = 0,
	channel_1,
	channel_2,
	channel_3,
	channel_4,
	channel_5,
	channel_6,
	channel_7,
	channel_8,
	channel_9,
	channel_10,
	channel_11,
	channel_12,
	channel_13,
	channel_14,
	channel_15,
	channel_16,
	channel_17,
	channel_18,
	channel_19,
	channel_20,
	channel_21,
	channel_22,
	channel_23,
	channel_24,
	channel_25,
	channel_26,
	channel_27,
	channel_28,
	channel_29,
	channel_30,
	channel_31
};

enum TRANS_MODE {
	transparent = 0,
	fixed
};

enum IO_DRIVE {
	open_collector = 0,
	push_pull
};

enum WAKE_TIME {
	wake_250ms = 0,
	wake_500ms,
	wake_750ms,
	wake_1000ms,
	wake_1250ms,
	wake_1500ms,
	wake_1750ms,
	wake_2000ms,
};

enum FEC {
	fec_off = 0,
	fec_on
};

enum TRANS_POWER {
	power_20dBm = 0,
	power_17dBm,
	power_14dBm,
	power_10dBm
};


struct EbyteSettings {
	enum HEAD head;
	enum UART_PARITY parity;
	enum UART_BAUD_RATE baud;
	enum AIR_RATE air_rate;
	enum COM_CHANNEL channel;
	enum TRANS_MODE mode;
	enum IO_DRIVE drive;
	enum WAKE_TIME wake;
	enum FEC fec;
	enum TRANS_POWER power;
};
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
